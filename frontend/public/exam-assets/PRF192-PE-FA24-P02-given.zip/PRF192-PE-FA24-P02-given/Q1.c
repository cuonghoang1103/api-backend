#include <stdio.h>
void calAreaOfCircle(double r) {
    // TODO: write your solution here

}
int main() {
    double radius;
    printf("Enter radius=");
    scanf("%lf", &radius);
    printf("\nOUTPUT:\n");
    calAreaOfCircle(radius);
    return 0;
}
