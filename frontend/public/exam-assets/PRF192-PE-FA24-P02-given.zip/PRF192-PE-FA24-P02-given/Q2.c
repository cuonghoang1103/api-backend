#include <stdio.h>
void calculate(int n) {
    // TODO: write your solution here (print S(n), 2 decimal places)

}
int main() {
    int n;
    printf("Enter a number = ");
    scanf("%d", &n);
    printf("\nOUTPUT:\n");
    calculate(n);
    return 0;
}
