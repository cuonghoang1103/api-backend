#include <stdio.h>
#define MAX 100
void input(int a[], int n) {
    for (int i = 0; i < n; i++) {
        printf("a[%d]:", i);
        scanf("%d", &a[i]);
    }
}
int countEnd(int a[], int n, int x) {
    // TODO: write your solution here

    return 0;
}
int main() {
    int n, x, count;
    int a[MAX];
    printf("Enter number of elements:");
    scanf("%d", &n);
    input(a, n);
    printf("Enter x:");
    scanf("%d", &x);
    printf("\nOUTPUT:\n");
    count = countEnd(a, n, x);
    printf("%d\n", count);
    return 0;
}
