#include <stdio.h>
#include <string.h>
#include <ctype.h>
int countWords(char* s, char* k) {
    // TODO: write your solution here (count occurrences of k in s)

    return 0;
}
int main() {
    char s[101], k[101];
    printf("Please enter string s: ");
    scanf("%100[^\n]", s);
    getchar();
    printf("Please enter string k: ");
    scanf("%100[^\n]", k);
    printf("\nOUTPUT:\n");
    printf("%d\n", countWords(s, k));
    return 0;
}
