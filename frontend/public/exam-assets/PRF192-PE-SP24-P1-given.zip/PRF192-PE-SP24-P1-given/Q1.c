#include <stdio.h>
void printNumber(float a, float b) {
    // TODO: write your solution here

}
int main() {
    float a, b;
    printf("a= ");
    scanf("%f", &a);
    printf("b= ");
    scanf("%f", &b);
    printf("\nOUTPUT:\n");
    printNumber(a, b);
    return 0;
}
