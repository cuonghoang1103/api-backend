#include <stdio.h>
double calculateS(int n) {
    double sum = 0;
    // TODO: write your solution here

    return sum;
}
int main() {
    int n;
    double sum;
    do {
        printf("Enter n = ");
        scanf("%d", &n);
    } while (n <= 0);
    printf("\nOUTPUT:\n");
    sum = calculateS(n);
    printf("%.2lf\n", sum);
    return 0;
}
