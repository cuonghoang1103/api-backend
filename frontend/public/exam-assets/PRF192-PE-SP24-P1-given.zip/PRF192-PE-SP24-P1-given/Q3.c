#include <stdio.h>
int countEvenGreaterX(int a[], int n, int x) {
    int count = 0;
    // TODO: write your solution here

    return count;
}
void input(int a[], int *pn, int *px) {
    printf("Enter number of elements : ");
    scanf("%d", pn);
    for (int i = 0; i < *pn; i++) {
        printf("a[%d]=", i);
        scanf("%d", &a[i]);
    }
    printf("Enter x=");
    scanf("%d", px);
}
int main() {
    int a[100], n, count, x;
    input(a, &n, &x);
    count = countEvenGreaterX(a, n, x);
    printf("OUTPUT:\n");
    printf("%d\n", count);
    return 0;
}
