#include <stdio.h>
#include <string.h>
#include <ctype.h>
int countCharacter(char* str, char ch) {
    int count = 0;
    // TODO: write your solution here

    return count;
}
int main() {
    char str[51], ch;
    printf("Please enter a string: ");
    scanf("%50[^\n]", str);
    getchar();
    printf("Please enter a character: ");
    scanf("%c", &ch);
    printf("\nOUTPUT:\n");
    printf("%d\n", countCharacter(str, ch));
    return 0;
}
