#include <stdio.h>
int main() {
    int n;
    scanf("%d", &n);
    // TODO: print the maximum number formed by rearranging the 3 digits of n

    return 0;
}
