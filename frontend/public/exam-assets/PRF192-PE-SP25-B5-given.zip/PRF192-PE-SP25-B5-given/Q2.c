#include <stdio.h>
int main() {
    int n;
    scanf("%d", &n);
    int t[100];
    for (int i = 0; i < n; i++) scanf("%d", &t[i]);
    // TODO: print the time taken by the runner-up (2nd place)

    return 0;
}
