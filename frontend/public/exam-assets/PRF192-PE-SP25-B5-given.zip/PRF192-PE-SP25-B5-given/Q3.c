#include <stdio.h>
int main() {
    char str[101];
    fgets(str, sizeof(str), stdin);
    char ch;
    scanf("%c", &ch);
    // TODO: print all indices of ch in str (space separated), or -1 if not found

    return 0;
}
