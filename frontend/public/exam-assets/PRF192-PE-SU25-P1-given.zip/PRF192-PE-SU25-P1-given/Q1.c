#include <stdio.h>
double calculate_water_bill(double water_usage) {
    // TODO: write your solution here

}
int main() {
    double water_usage;
    printf("Enter water usage in cubic meters: ");
    scanf("%lf", &water_usage);
    double result = calculate_water_bill(water_usage);
    printf("OUTPUT:\n");
    printf("%.2lf\n", result);
    return 0;
}
