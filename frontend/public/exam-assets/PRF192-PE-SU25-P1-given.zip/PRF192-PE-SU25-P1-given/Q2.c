#include <stdio.h>
int sumPowerDigits(int num) {
    int sum = 0;
    // TODO: write your solution here

    return sum;
}
int main() {
    int n, sum;
    printf("Enter n = ");
    scanf("%d", &n);
    printf("\nOUTPUT:\n");
    sum = sumPowerDigits(n);
    printf("%d\n", sum);
    return 0;
}
