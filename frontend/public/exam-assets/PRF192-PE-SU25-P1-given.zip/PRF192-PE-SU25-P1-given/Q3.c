#include <stdio.h>
int sum(int a[], int n) {
    int sum = 0;
    // TODO: write your solution here

    return sum;
}
void input(int a[], int *pn) {
    printf("Enter the number of elements:");
    scanf("%d", pn);
    for (int i = 0; i < *pn; i++) {
        printf("a[%d]=", i);
        scanf("%d", &a[i]);
    }
}
int main() {
    int a[50], n, result;
    input(a, &n);
    printf("OUTPUT:\n");
    result = sum(a, n);
    printf("%d\n", result);
    return 0;
}
