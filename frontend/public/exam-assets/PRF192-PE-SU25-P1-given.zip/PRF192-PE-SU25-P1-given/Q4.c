#include <stdio.h>
#include <string.h>
#include <ctype.h>
void changeNotLetter2Star(char* s) {
    // TODO: write your solution here

}
int main() {
    char s[51];
    printf("Please enter a string: ");
    scanf("%50[^\n]", s);
    printf("OUTPUT:\n");
    changeNotLetter2Star(s);
    puts(s);
    return 0;
}
