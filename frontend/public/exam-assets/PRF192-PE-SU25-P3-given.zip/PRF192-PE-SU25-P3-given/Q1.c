#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main() {
  //INPUT - @STUDENT: ADD YOUR CODE FOR INPUT HERE:



  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:



  return 0;
}
