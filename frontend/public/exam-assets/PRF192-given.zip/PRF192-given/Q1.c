#include <stdio.h>

int main() {
    // TODO: Q1 — write your solution here / viết lời giải câu 1 ở đây
    return 0;
}
