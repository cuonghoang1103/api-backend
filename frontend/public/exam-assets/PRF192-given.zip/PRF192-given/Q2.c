#include <stdio.h>

int main() {
    // TODO: Q2 — write your solution here / viết lời giải câu 2 ở đây
    return 0;
}
