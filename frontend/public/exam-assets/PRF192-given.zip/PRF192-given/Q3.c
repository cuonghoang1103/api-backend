#include <stdio.h>

int main() {
    // TODO: Q3 — write your solution here / viết lời giải câu 3 ở đây
    return 0;
}
