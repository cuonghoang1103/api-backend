#include <stdio.h>

int main() {
    // TODO: Q4 — write your solution here / viết lời giải câu 4 ở đây
    return 0;
}
