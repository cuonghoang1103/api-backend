PRF192 — Practical Exam (starter files)
========================================
1. Edit each file Q1.c … Q8.c with your solution.
   (Sửa mỗi file Q1.c … Q8.c với lời giải của bạn.)
2. Keep the file names EXACTLY as given (Q1.c, Q2.c, ...).
   (Giữ NGUYÊN tên file như đề — Q1.c, Q2.c, ...)
3. Test your program against the example input/output in the exam.
   (Chạy thử với ví dụ input/output trong đề.)
4. Select all .c files, compress into ONE .zip, and upload in the exam room.
   (Chọn tất cả file .c, nén thành MỘT file .zip, rồi tải lên phòng thi.)
